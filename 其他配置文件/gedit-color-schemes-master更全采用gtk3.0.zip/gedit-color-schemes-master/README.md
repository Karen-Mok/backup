These are syntax highlight text color schemes for Gedit (or apps that use GtkSourceView).

Some of these were made for Gedit 2 (GtkSourceView 2) and might need some tweaking for Gedit 3 (GtkSourceView 3), but they still work for the most part. Some might be duplicates, but I saved 'em just in case. Enjoy.
The 2.0 files work (for the most part) with 3.0, but I haven't tested the 3.0 files with 2.0.

Place them in `/usr/share/gtksourceview-{2,3}.0/styles/`, corresponding to the folders in this repo. You can replace `/usr/share/` with `~/.local/share/` to install locally instead of systemwide.
