#!/usr/bin/env bash

sudo cp --no-clobber ./*.xml /usr/share/gtksourceview-3.0/styles
